# MORAI command application diagnosis

The latest logs showed that `/ctrl_cmd_0` was being published, but `/Ego_topic` still reported:

- `front_steer_angle: 0.0`
- `accel: 0.0`
- `brake: 0.0`

while the vehicle moved straight. That means the problem is below Hybrid A*, below Pure Pursuit, and below reference trajectory generation: MORAI is not applying the `CtrlCmd` as expected.

This package therefore changes the low-level adapter behavior:

1. Publishes the same `CtrlCmd` to both `/ctrl_cmd_0` and `/ctrl_cmd` by default.
2. Repeats AutoMode/API-mode service requests using candidates `3,4`.
3. Gear requests include `ctrl_mode=4`, matching the MORAI practice code pattern.
4. Adapter debug now reports `ctrl_conn=primary/secondary` so we can see whether MORAI subscribes to the control topics.
5. Added `morai_command_probe.launch` to test low-level command acceptance without planner/tracker.

Run the probe first:

```bash
roslaunch alpha_control morai_command_probe.launch
rostopic echo -n 1 /alpha_control/morai_command_probe_report
```

If it reports zero subscribers or Ego fields stay zero, the parking planner cannot control MORAI until AutoMode/topic/message convention is corrected.
