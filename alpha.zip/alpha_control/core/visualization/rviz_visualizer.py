# -*- coding: utf-8 -*-
"""RViz visualization wrapper. ROS-dependent code is isolated here."""

import math
from typing import List, Optional

from core.common.geometry import rear_axle_to_body_center
from core.common.types import DensePathPoint, RectObstacle, RefTrajectoryPoint
from core.planning.hybrid_astar import HybridAStarPlanner

class RvizVisualizer:
    def __init__(self, planner: HybridAStarPlanner, start, goal, slot_centers: Optional[List[float]] = None, slot_polygons: Optional[List[List[tuple]]] = None):
        import rospy
        from nav_msgs.msg import Path
        from visualization_msgs.msg import MarkerArray

        self.rospy = rospy
        self.planner = planner
        self.start = start
        self.goal = goal
        self.slot_centers = slot_centers or [-0.65, 1.60, 3.85, 6.10, 8.35, 10.60]
        self.slot_polygons = slot_polygons
        self.static_pub = rospy.Publisher("/alpha_control/static_markers", MarkerArray, queue_size=1, latch=True)
        self.search_pub = rospy.Publisher("/alpha_control/search_markers", MarkerArray, queue_size=1)
        self.partial_pub = rospy.Publisher("/alpha_control/partial_path", Path, queue_size=1)
        self.raw_pub = rospy.Publisher("/alpha_control/path_raw", Path, queue_size=1, latch=True)
        self.ref_pub = rospy.Publisher("/alpha_control/path_ref", Path, queue_size=1, latch=True)
        self.final_pub = rospy.Publisher("/alpha_control/final_markers", MarkerArray, queue_size=1, latch=True)
        self.ref_marker_pub = rospy.Publisher("/alpha_control/ref_markers", MarkerArray, queue_size=1, latch=True)

    def q_from_yaw(self, yaw):
        import tf.transformations
        return tf.transformations.quaternion_from_euler(0.0, 0.0, yaw)

    def header(self):
        from std_msgs.msg import Header
        h = Header()
        h.stamp = self.rospy.Time.now()
        h.frame_id = "map"
        return h

    def point(self, x, y, z=0.0):
        from geometry_msgs.msg import Point
        p = Point()
        p.x = x
        p.y = y
        p.z = z
        return p

    def color(self, r, g, b, a=1.0):
        from std_msgs.msg import ColorRGBA
        c = ColorRGBA()
        c.r, c.g, c.b, c.a = r, g, b, a
        return c

    def marker(self, mid, ns, marker_type):
        from visualization_msgs.msg import Marker
        m = Marker()
        m.header = self.header()
        m.ns = ns
        m.id = int(mid)
        m.type = marker_type
        m.action = Marker.ADD
        m.pose.orientation.w = 1.0
        return m

    def delete_all(self):
        from visualization_msgs.msg import Marker
        m = Marker()
        m.action = Marker.DELETEALL
        return m

    def line_strip(self, mid, ns, pts, rgba, width=0.04, z=0.04):
        from visualization_msgs.msg import Marker
        m = self.marker(mid, ns, Marker.LINE_STRIP)
        m.scale.x = width
        m.color = self.color(*rgba)
        for x, y in pts:
            m.points.append(self.point(x, y, z))
        return m

    def line_list(self, mid, ns, segs, rgba, width=0.025, z=0.05):
        from visualization_msgs.msg import Marker
        m = self.marker(mid, ns, Marker.LINE_LIST)
        m.scale.x = width
        m.color = self.color(*rgba)
        for x1, y1, x2, y2 in segs:
            m.points.append(self.point(x1, y1, z))
            m.points.append(self.point(x2, y2, z))
        return m

    def points_marker(self, mid, ns, pts, rgba, scale=0.06, z=0.05):
        from visualization_msgs.msg import Marker
        m = self.marker(mid, ns, Marker.POINTS)
        m.scale.x = scale
        m.scale.y = scale
        m.color = self.color(*rgba)
        for x, y in pts:
            m.points.append(self.point(x, y, z))
        return m

    def cube(self, mid, ns, x, y, yaw, length, width, height, rgba):
        from visualization_msgs.msg import Marker
        m = self.marker(mid, ns, Marker.CUBE)
        m.pose.position.x = x
        m.pose.position.y = y
        m.pose.position.z = height * 0.5
        q = self.q_from_yaw(yaw)
        m.pose.orientation.x, m.pose.orientation.y, m.pose.orientation.z, m.pose.orientation.w = q
        m.scale.x = length
        m.scale.y = width
        m.scale.z = height
        m.color = self.color(*rgba)
        return m

    def vehicle_cube(self, mid, ns, rear_x, rear_y, yaw, height, rgba):
        # Vehicle pose is rear axle center, but RViz CUBE marker pose is body center.
        cfg = self.planner.cfg
        cx, cy = rear_axle_to_body_center(rear_x, rear_y, yaw, cfg.wheel_base, cfg.front_overhang, cfg.rear_overhang)
        return self.cube(mid, ns, cx, cy, yaw, cfg.vehicle_length, cfg.vehicle_width, height, rgba)

    def arrow(self, mid, ns, x, y, yaw, rgba, length=0.8):
        from visualization_msgs.msg import Marker
        m = self.marker(mid, ns, Marker.ARROW)
        m.pose.position.x = x
        m.pose.position.y = y
        m.pose.position.z = 0.17
        q = self.q_from_yaw(yaw)
        m.pose.orientation.x, m.pose.orientation.y, m.pose.orientation.z, m.pose.orientation.w = q
        m.scale.x = length
        m.scale.y = 0.14
        m.scale.z = 0.14
        m.color = self.color(*rgba)
        return m

    def text(self, mid, ns, text, x, y, z, scale, rgba):
        from visualization_msgs.msg import Marker
        m = self.marker(mid, ns, Marker.TEXT_VIEW_FACING)
        m.pose.position.x = x
        m.pose.position.y = y
        m.pose.position.z = z
        m.scale.z = scale
        m.color = self.color(*rgba)
        m.text = text
        return m

    def path_msg_from_dense(self, dense: List[DensePathPoint]):
        from nav_msgs.msg import Path
        from geometry_msgs.msg import PoseStamped
        msg = Path()
        msg.header = self.header()
        for p in dense:
            ps = PoseStamped()
            ps.header = msg.header
            ps.pose.position.x = p.x
            ps.pose.position.y = p.y
            ps.pose.position.z = 0.0
            q = self.q_from_yaw(p.yaw)
            ps.pose.orientation.x, ps.pose.orientation.y, ps.pose.orientation.z, ps.pose.orientation.w = q
            msg.poses.append(ps)
        return msg

    def path_msg_from_ref(self, ref: List[RefTrajectoryPoint]):
        from nav_msgs.msg import Path
        from geometry_msgs.msg import PoseStamped
        msg = Path()
        msg.header = self.header()
        for p in ref:
            ps = PoseStamped()
            ps.header = msg.header
            ps.pose.position.x = p.x
            ps.pose.position.y = p.y
            ps.pose.position.z = 0.0
            q = self.q_from_yaw(p.yaw)
            ps.pose.orientation.x, ps.pose.orientation.y, ps.pose.orientation.z, ps.pose.orientation.w = q
            msg.poses.append(ps)
        return msg

    def publish_static(self):
        from visualization_msgs.msg import MarkerArray
        ma = MarkerArray()
        ma.markers.append(self.delete_all())
        mid = 1
        cfg = self.planner.cfg

        # Map boundary.
        boundary = [(cfg.min_x, cfg.min_y), (cfg.max_x, cfg.min_y), (cfg.max_x, cfg.max_y), (cfg.min_x, cfg.max_y), (cfg.min_x, cfg.min_y)]
        ma.markers.append(self.line_strip(mid, "map_boundary", boundary, (0.85, 0.85, 0.85, 1.0), 0.05, 0.02)); mid += 1

        # Drivable area outer polygon.
        outer = self.planner.drivable_area.outer_polygon + [self.planner.drivable_area.outer_polygon[0]]
        ma.markers.append(self.line_strip(mid, "manual_drivable_area_outer", outer, (0.1, 1.0, 0.25, 1.0), 0.085, 0.12)); mid += 1
        ma.markers.append(self.text(mid, "manual_drivable_label", "MANUAL DRIVABLE AREA\n(aisle + target slot only)", cfg.min_x + 2.5, cfg.min_y + 0.8, 0.55, 0.30, (0.1, 1.0, 0.25, 1.0))); mid += 1

        # Forbidden polygons.
        for name, poly in self.planner.drivable_area.forbidden_polygons:
            ma.markers.append(self.line_strip(mid, "manual_forbidden_area", poly + [poly[0]], (1.0, 0.2, 0.1, 0.75), 0.04, 0.10)); mid += 1

        # Parking-slot guide lines. For MORAI absolute-coordinate scenarios,
        # slot_polygons are supplied directly in world coordinates.
        if self.slot_polygons:
            for i, slot_poly in enumerate(self.slot_polygons):
                color = (1.0, 0.85, 0.05, 1.0) if i == 0 else (0.75, 0.75, 0.75, 0.35)
                width = 0.060 if i == 0 else 0.030
                ma.markers.append(self.line_strip(mid, "parking_slot_lines", slot_poly + [slot_poly[0]], color, width, 0.08)); mid += 1
        else:
            slot_center_y = cfg.slot_length * 0.5
            for sx in self.slot_centers:
                slot_poly = RectObstacle(sx, slot_center_y, self.goal[2], cfg.slot_length, cfg.slot_width, "slot").polygon(0.0)
                color = (1.0, 0.85, 0.05, 1.0) if abs(sx - self.goal[0]) < 0.1 else (0.75, 0.75, 0.75, 0.35)
                width = 0.055 if abs(sx - self.goal[0]) < 0.1 else 0.025
                ma.markers.append(self.line_strip(mid, "parking_slot_lines", slot_poly + [slot_poly[0]], color, width, 0.08)); mid += 1

        # Obstacles.
        for obs in self.planner.obstacles:
            is_wall = "wall" in obs.name or "boundary" in obs.name or "curb" in obs.name
            color = (0.55, 0.55, 0.55, 0.85) if is_wall else (0.95, 0.08, 0.08, 0.85)
            ma.markers.append(self.cube(mid, "obstacles", obs.x, obs.y, obs.yaw, obs.length, obs.width, 0.22, color)); mid += 1

        # Start/goal vehicle.
        ma.markers.append(self.vehicle_cube(mid, "start_vehicle", self.start[0], self.start[1], self.start[2], 0.16, (0.05, 0.95, 0.20, 0.45))); mid += 1
        ma.markers.append(self.arrow(mid, "start_arrow", self.start[0], self.start[1], self.start[2], (0.05, 1.0, 0.20, 1.0), 1.1)); mid += 1
        ma.markers.append(self.text(mid, "start_text", "START", self.start[0], self.start[1] - 1.0, 0.35, 0.32, (0.05, 1.0, 0.20, 1.0))); mid += 1

        ma.markers.append(self.vehicle_cube(mid, "goal_vehicle", self.goal[0], self.goal[1], self.goal[2], 0.16, (1.0, 0.85, 0.05, 0.40))); mid += 1
        ma.markers.append(self.arrow(mid, "goal_arrow", self.goal[0], self.goal[1], self.goal[2], (1.0, 0.85, 0.05, 1.0), 1.1)); mid += 1
        ma.markers.append(self.text(mid, "goal_text", "REAR PARKING GOAL\nfront faces aisle", self.goal[0], self.goal[1] + 2.6, 0.45, 0.28, (1.0, 0.85, 0.05, 1.0))); mid += 1

        legend = "Hybrid A* + Manual Drivable Area + Rear-Axle Reference Trajectory\n" \
                 "green boundary: manually allowed drivable polygon\n" \
                 "red boundary: forbidden / non-drivable area\n" \
                 "cyan/gray: open/closed search nodes\n" \
                 "blue/magenta: raw forward/reverse path\n" \
                 "yellow arrows/path: generated reference trajectory"
        ma.markers.append(self.text(mid, "legend", legend, cfg.min_x + 3.0, cfg.max_y - 0.75, 0.55, 0.24, (1.0, 1.0, 1.0, 0.95))); mid += 1
        self.static_pub.publish(ma)

    def publish_search_step(self, current, current_id, open_heap, nodes, closed, visual_edges, latest_edges, rejected, step_count):
        from visualization_msgs.msg import MarkerArray
        ma = MarkerArray()
        max_nodes = 2500
        closed_pts = [(n.x, n.y) for n in list(closed.values())[-max_nodes:]]
        open_pts = []
        seen = set()
        for _, _, node_id in reversed(open_heap):
            n = nodes[node_id]
            if n.index in closed or n.index in seen:
                continue
            open_pts.append((n.x, n.y))
            seen.add(n.index)
            if len(open_pts) >= max_nodes:
                break
        ma.markers.append(self.points_marker(1, "closed_nodes", closed_pts, (0.55, 0.55, 0.55, 0.70), 0.055, 0.05))
        ma.markers.append(self.points_marker(2, "open_nodes", open_pts, (0.1, 0.75, 1.0, 0.85), 0.06, 0.06))
        ma.markers.append(self.line_list(3, "all_expansion_edges", visual_edges[-4500:], (1.0, 0.50, 0.0, 0.30), 0.018, 0.04))
        ma.markers.append(self.line_list(4, "latest_expansion_edges", latest_edges, (1.0, 0.78, 0.05, 0.95), 0.045, 0.08))
        ma.markers.append(self.points_marker(5, "rejected_candidates", rejected, (1.0, 0.0, 0.0, 0.90), 0.09, 0.09))
        ma.markers.append(self.arrow(6, "current_node", current.x, current.y, current.yaw, (1.0, 1.0, 0.0, 1.0), 0.9))
        ma.markers.append(self.vehicle_cube(7, "current_vehicle", current.x, current.y, current.yaw, 0.15, (1.0, 1.0, 0.05, 0.28)))
        status = "step: %d\nopen: %d\nclosed: %d\nf: %.2f\ng: %.2f\nh: %.2f\ngear: %s\nsteer: %.1f deg" % (
            step_count, len(open_heap), len(closed), current.f, current.g, current.h, "D" if current.direction >= 0 else "R", math.degrees(current.steer))
        ma.markers.append(self.text(8, "search_status", status, self.planner.cfg.max_x - 2.4, self.planner.cfg.min_y + 1.2, 0.55, 0.28, (1.0, 1.0, 1.0, 0.95)))
        self.search_pub.publish(ma)

        # Partial path to the current node.
        try:
            chain = self.planner.reconstruct_chain(nodes, current_id)
            dense = self.planner.chain_to_dense_path(chain)
            self.partial_pub.publish(self.path_msg_from_dense(dense))
        except Exception:
            pass

    def publish_raw_and_ref(self, raw: List[DensePathPoint], ref: List[RefTrajectoryPoint], csv_path: str):
        from visualization_msgs.msg import MarkerArray
        self.raw_pub.publish(self.path_msg_from_dense(raw))
        self.ref_pub.publish(self.path_msg_from_ref(ref))

        ma = MarkerArray(); ma.markers.append(self.delete_all())
        mid = 1
        forward, reverse = [], []
        for a, b in zip(raw[:-1], raw[1:]):
            seg = (a.x, a.y, b.x, b.y)
            if b.direction >= 0:
                forward.append(seg)
            else:
                reverse.append(seg)
        ma.markers.append(self.line_list(mid, "raw_forward_path", forward, (0.05, 0.35, 1.0, 1.0), 0.085, 0.20)); mid += 1
        ma.markers.append(self.line_list(mid, "raw_reverse_path", reverse, (1.0, 0.0, 0.85, 1.0), 0.085, 0.22)); mid += 1

        # Reference trajectory as yellow line and arrows.
        ref_segs = [(a.x, a.y, b.x, b.y) for a, b in zip(ref[:-1], ref[1:])]
        ma.markers.append(self.line_list(mid, "reference_trajectory", ref_segs, (1.0, 1.0, 0.05, 1.0), 0.040, 0.32)); mid += 1
        arrow_step = max(1, int(len(ref) / 18))
        for i in range(0, len(ref), arrow_step):
            p = ref[i]
            rgba = (1.0, 1.0, 0.05, 1.0) if p.gear >= 0 else (1.0, 0.55, 0.05, 1.0)
            ma.markers.append(self.arrow(mid, "reference_arrows", p.x, p.y, p.yaw, rgba, 0.45)); mid += 1

        if raw:
            last = raw[-1]
            ma.markers.append(self.vehicle_cube(mid, "final_vehicle", last.x, last.y, last.yaw, 0.18, (0.15, 1.0, 0.30, 0.45))); mid += 1

        stats = self.planner.last_stats
        text = "RESULT\nraw path points: %d\nref traj points: %d\ntime length: %.2fs\npath length: %.2fm\ngear changes: %d\nCSV: %s" % (
            len(raw), len(ref), ref[-1].t if ref else 0.0, stats.get("path_length", 0.0), int(stats.get("gear_changes", 0)), csv_path)
        ma.markers.append(self.text(mid, "result_text", text, self.planner.cfg.max_x - 2.65, self.planner.cfg.max_y - 1.10, 0.62, 0.26, (0.2, 1.0, 0.2, 1.0))); mid += 1
        self.final_pub.publish(ma)

        # Separate reference marker details.
        rm = MarkerArray(); rm.markers.append(self.delete_all())
        mid = 1
        detail_step = max(1, int(len(ref) / 10))
        for i in range(0, len(ref), detail_step):
            p = ref[i]
            label = "t=%.1f\nv=%.2f\nsteer=%.1f\n%s" % (p.t, p.v, math.degrees(p.steer), "D" if p.gear >= 0 else "R")
            rm.markers.append(self.text(mid, "ref_point_info", label, p.x, p.y, 0.55, 0.18, (1.0, 1.0, 0.05, 0.95))); mid += 1
        self.ref_marker_pub.publish(rm)

