# -*- coding: utf-8 -*-
"""Reference trajectory generation from Hybrid A* raw path."""

import math
from typing import List, Tuple

from core.common.geometry import angle_diff, clamp, cumulative_distance_xy, normalize_angle
from core.common.types import DensePathPoint, PlannerConfig, RefTrajectoryPoint


class ReferenceTrajectoryGenerator:
    def __init__(self, cfg: PlannerConfig):
        self.cfg = cfg

    def resample_segment(self, segment: List[DensePathPoint], ds: float) -> List[Tuple[float, float, int, float]]:
        """Return (x, y, gear, raw_steer) resampled points for one gear segment."""
        if len(segment) < 2:
            return []
        gear = segment[1].direction
        raw_xy = [(p.x, p.y) for p in segment]
        raw_s = cumulative_distance_xy(raw_xy)
        total = raw_s[-1]
        if total < 1e-6:
            return []
        out = []
        n = max(2, int(math.ceil(total / ds)) + 1)
        j = 0
        for i in range(n):
            target_s = min(total, float(i) * total / float(n - 1))
            while j + 1 < len(raw_s) and raw_s[j + 1] < target_s:
                j += 1
            if j + 1 >= len(raw_s):
                x, y = raw_xy[-1]
                steer = segment[-1].steer
            else:
                s0, s1 = raw_s[j], raw_s[j + 1]
                ratio = 0.0 if abs(s1 - s0) < 1e-9 else (target_s - s0) / (s1 - s0)
                x0, y0 = raw_xy[j]
                x1, y1 = raw_xy[j + 1]
                x = x0 + (x1 - x0) * ratio
                y = y0 + (y1 - y0) * ratio
                steer = segment[j + 1].steer
            out.append((x, y, gear, steer))
        return out

    def split_by_gear(self, raw: List[DensePathPoint]) -> List[List[DensePathPoint]]:
        if len(raw) < 2:
            return []
        segments = []
        cur = [raw[0]]
        prev_gear = raw[1].direction
        for p in raw[1:]:
            gear = p.direction
            if gear != prev_gear and len(cur) > 1:
                segments.append(cur)
                cur = [cur[-1]]
            cur.append(p)
            prev_gear = gear
        if len(cur) > 1:
            segments.append(cur)
        return segments

    def generate(self, raw: List[DensePathPoint]) -> List[RefTrajectoryPoint]:
        """
        Pipeline:
          raw path -> gear segment split -> waypoint interpolation -> yaw recomputation
          -> curvature/steering -> cubic speed profile -> time stamped ref trajectory
        """
        segments = self.split_by_gear(raw)
        ref: List[RefTrajectoryPoint] = []
        global_t = 0.0
        global_s = 0.0

        for seg in segments:
            samples = self.resample_segment(seg, self.cfg.ref_ds)
            if len(samples) < 2:
                continue

            xy = [(x, y) for x, y, _, _ in samples]
            s_list = cumulative_distance_xy(xy)
            S = max(s_list[-1], 1e-6)
            T = max(self.cfg.min_segment_time, 1.65 * S / max(self.cfg.max_ref_speed, 1e-3))

            # Heading and vehicle yaw. For reverse gear, vehicle yaw is path heading + pi.
            yaw_list = []
            for i in range(len(samples)):
                if i < len(samples) - 1:
                    dx = samples[i + 1][0] - samples[i][0]
                    dy = samples[i + 1][1] - samples[i][1]
                else:
                    dx = samples[i][0] - samples[i - 1][0]
                    dy = samples[i][1] - samples[i - 1][1]
                path_heading = math.atan2(dy, dx)
                gear = samples[i][2]
                yaw = path_heading if gear >= 0 else normalize_angle(path_heading + math.pi)
                yaw_list.append(normalize_angle(yaw))

            curvature_list = []
            steer_list = []
            for i in range(len(samples)):
                if i == 0:
                    dyaw = angle_diff(yaw_list[1], yaw_list[0])
                    ds_val = max(s_list[1] - s_list[0], 1e-6)
                elif i == len(samples) - 1:
                    dyaw = angle_diff(yaw_list[-1], yaw_list[-2])
                    ds_val = max(s_list[-1] - s_list[-2], 1e-6)
                else:
                    dyaw = angle_diff(yaw_list[i + 1], yaw_list[i - 1])
                    ds_val = max(s_list[i + 1] - s_list[i - 1], 1e-6)
                kappa = dyaw / ds_val
                steer = math.atan(self.cfg.wheel_base * kappa)
                steer = clamp(steer, -self.cfg.max_steer, self.cfg.max_steer)
                curvature_list.append(kappa)
                steer_list.append(steer)

            # Cubic speed profile: s(t)=S(3r^2-2r^3), v = ds/dt, a = dv/dt.
            for i, (x, y, gear, _) in enumerate(samples):
                local_s = s_list[i]
                r = clamp(local_s / S, 0.0, 1.0)
                local_t = r * T
                v_mag = (S / T) * (6.0 * r - 6.0 * r * r)
                a_mag = (S / (T * T)) * (6.0 - 12.0 * r)
                v = float(gear) * v_mag
                a = float(gear) * a_mag
                if ref and i == 0:
                    continue
                ref.append(RefTrajectoryPoint(
                    t=global_t + local_t,
                    x=x,
                    y=y,
                    yaw=yaw_list[i],
                    s=global_s + local_s,
                    v=v,
                    a=a,
                    curvature=curvature_list[i],
                    steer=steer_list[i],
                    gear=gear,
                ))
            global_t += T
            global_s += S

        return ref
