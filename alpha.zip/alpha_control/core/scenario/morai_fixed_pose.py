# -*- coding: utf-8 -*-
"""MORAI fixed-pose rear parking scenario.

This scenario is generated from the user's measured /Ego_topic samples.
Important: in this version, all user-provided poses are treated as
rear-axle-center poses by default.

The planner, tracker, and MORAI adapter all use rear-axle-center pose.
Only obstacle rectangles are converted to body-center rectangles internally
for collision checking, because a RectObstacle stores its geometric center.
"""

import math
from typing import Dict, List, Tuple

from core.common.geometry import rotate_point
from core.common.types import DensePathPoint, PlannerConfig, RectObstacle
from core.planning.drivable_area import DrivableArea


def deg2rad(d: float) -> float:
    return math.radians(float(d))


def pose_center_to_rear(x: float, y: float, yaw: float, center_to_rear_axle: float) -> Tuple[float, float, float]:
    return (
        float(x) - center_to_rear_axle * math.cos(float(yaw)),
        float(y) - center_to_rear_axle * math.sin(float(yaw)),
        float(yaw),
    )


def pose_rear_to_center(x: float, y: float, yaw: float, center_to_rear_axle: float) -> Tuple[float, float, float]:
    return (
        float(x) + center_to_rear_axle * math.cos(float(yaw)),
        float(y) + center_to_rear_axle * math.sin(float(yaw)),
        float(yaw),
    )


def world_to_local(x: float, y: float, origin_x: float, origin_y: float, row_yaw: float) -> Tuple[float, float]:
    """World to local frame with local x=row/aisle direction, local y=slot direction."""
    dx = x - origin_x
    dy = y - origin_y
    c = math.cos(row_yaw)
    s = math.sin(row_yaw)
    # dot with row axis and slot axis(row+90)
    lx = dx * c + dy * s
    ly = -dx * s + dy * c
    return lx, ly


def local_to_world(lx: float, ly: float, origin_x: float, origin_y: float, row_yaw: float) -> Tuple[float, float]:
    c = math.cos(row_yaw)
    s = math.sin(row_yaw)
    return origin_x + lx * c - ly * s, origin_y + lx * s + ly * c


def local_yaw_to_world(local_yaw: float, row_yaw: float) -> float:
    a = local_yaw + row_yaw
    while a >= math.pi:
        a -= 2.0 * math.pi
    while a < -math.pi:
        a += 2.0 * math.pi
    return a


def normalize_angle(a: float) -> float:
    while a >= math.pi:
        a -= 2.0 * math.pi
    while a < -math.pi:
        a += 2.0 * math.pi
    return a


DEFAULT_SCENARIO = {
    # User measured samples from /Ego_topic.
    # These are rear-axle-center poses in this corrected version.
    "left_obstacle":  [9.997062683105469, 1040.122802734375, 62.44873046875],
    "right_obstacle": [14.390615463256836, 1037.8037109375, 62.36334228515625],
    "goal_pose":      [12.093697547912598, 1038.8704833984375, 61.917388916015625],
    "start_pose":     [10.105016708374023, 1047.2745361328125, -27.5059814453125],
}


def make_morai_fixed_pose_scenario(params: Dict, cfg: PlannerConfig):
    """Return obstacles, drivable_area, start_rear, goal_rear, debug_info.

    params keys:
      pose_origin: 'rear_axle' or 'center'
      start_pose, goal_pose, left_obstacle, right_obstacle: [x,y,yaw_deg]

    In the default rear_axle mode:
      - start_pose and goal_pose are used directly by planner/tracker.
      - left/right obstacle poses are rear-axle poses, so they are converted
        to body centers before creating RectObstacle objects.
    """
    pose_origin = str(params.get("pose_origin", "rear_axle"))
    c2r = float(params.get("center_to_rear_axle", cfg.vehicle_length * 0.5 - cfg.rear_overhang))

    start_c = params.get("start_pose", DEFAULT_SCENARIO["start_pose"])
    goal_c = params.get("goal_pose", DEFAULT_SCENARIO["goal_pose"])
    left_c = params.get("left_obstacle", DEFAULT_SCENARIO["left_obstacle"])
    right_c = params.get("right_obstacle", DEFAULT_SCENARIO["right_obstacle"])

    start_yaw = deg2rad(start_c[2])
    goal_yaw = deg2rad(goal_c[2])

    left_yaw = deg2rad(left_c[2])
    right_yaw = deg2rad(right_c[2])

    if pose_origin == "center":
        # Compatibility mode: input start/goal/obstacle poses are body centers.
        start = pose_center_to_rear(start_c[0], start_c[1], start_yaw, c2r)
        goal = pose_center_to_rear(goal_c[0], goal_c[1], goal_yaw, c2r)
        goal_body_center = (float(goal_c[0]), float(goal_c[1]))
        left_body_center = (float(left_c[0]), float(left_c[1]))
        right_body_center = (float(right_c[0]), float(right_c[1]))
    else:
        # Corrected default: input poses are already rear-axle-center poses.
        start = (float(start_c[0]), float(start_c[1]), start_yaw)
        goal = (float(goal_c[0]), float(goal_c[1]), goal_yaw)

        # RectObstacle stores geometric center, so convert parked-car rear poses
        # to body-center poses for obstacle collision boxes.
        goal_body_center = pose_rear_to_center(goal[0], goal[1], goal_yaw, c2r)[:2]
        left_body_center = pose_rear_to_center(left_c[0], left_c[1], left_yaw, c2r)[:2]
        right_body_center = pose_rear_to_center(right_c[0], right_c[1], right_yaw, c2r)[:2]

    parked_len = float(params.get("parked_vehicle_length", cfg.vehicle_length))
    parked_width = float(params.get("parked_vehicle_width", cfg.vehicle_width))
    obstacle_padding_len = float(params.get("obstacle_length_extra", 0.05))
    obstacle_padding_wid = float(params.get("obstacle_width_extra", 0.05))

    obstacles: List[RectObstacle] = [
        RectObstacle(left_body_center[0], left_body_center[1], left_yaw, parked_len + obstacle_padding_len, parked_width + obstacle_padding_wid, "left_parked_vehicle"),
        RectObstacle(right_body_center[0], right_body_center[1], right_yaw, parked_len + obstacle_padding_len, parked_width + obstacle_padding_wid, "right_parked_vehicle"),
    ]

    # Coordinate frame for manual drivable area.
    # local x = aisle/row direction, local y = parking slot longitudinal direction.
    row_yaw = normalize_angle(goal_yaw - math.pi * 0.5)
    ox, oy = goal_body_center

    # T-shaped hard drivable area: aisle + target slot only.
    half_slot_w = float(params.get("slot_width", cfg.slot_width)) * 0.5
    half_slot_l = float(params.get("slot_length", cfg.slot_length)) * 0.5

    # Slightly relaxed to allow vehicle length 4.43 m in a nominal 4.4 m slot.
    slot_w_margin = float(params.get("slot_width_margin", 0.12))
    slot_l_margin = float(params.get("slot_length_margin", 0.25))
    aisle_half_width = float(params.get("aisle_half_width", 2.15))
    row_min = float(params.get("row_min", -9.0))
    row_max = float(params.get("row_max", 9.0))

    # In this local frame, the aisle is in front of the slot center along +local_y.
    # Expand the manual drivable-area automatically to include the actual
    # start pose. This is important in MORAI tests because after a failed run
    # the Ego vehicle may no longer be exactly at the originally measured
    # start pose. If the start pose is outside the hard drivable polygon,
    # Hybrid A* cannot generate a valid path and the tracker will immediately
    # fall into OFF_PATH stop mode.
    start_local_r, start_local_s = world_to_local(start[0], start[1], ox, oy, row_yaw)

    aisle_y_min = half_slot_l - 0.20
    aisle_y_max = max(start_local_s + 2.4, half_slot_l + 4.0)

    row_min = min(row_min, start_local_r - 2.0)
    row_max = max(row_max, start_local_r + 2.0)

    sx_min = -half_slot_w - slot_w_margin
    sx_max = half_slot_w + slot_w_margin
    sy_min = -half_slot_l - slot_l_margin
    sy_max = half_slot_l + 0.15

    outer_local = [
        (row_min, aisle_y_max),
        (row_max, aisle_y_max),
        (row_max, aisle_y_min),
        (sx_max, aisle_y_min),
        (sx_max, sy_min),
        (sx_min, sy_min),
        (sx_min, aisle_y_min),
        (row_min, aisle_y_min),
    ]
    outer_world = [local_to_world(x, y, ox, oy, row_yaw) for x, y in outer_local]

    # Forbidden regions are implicitly outside the concave polygon. Add the two physical parked vehicles only.
    drivable_area = DrivableArea(outer_world, [], name="morai_fixed_manual_drivable_area")

    # Add a soft rear curb behind the slot as a physical boundary. It is behind local y = sy_min.
    curb_center = local_to_world(0.0, sy_min - 0.25, ox, oy, row_yaw)
    obstacles.append(RectObstacle(curb_center[0], curb_center[1], row_yaw, cfg.slot_width + 2.0, 0.12, "rear_virtual_curb"))

    debug = {
        "pose_origin": pose_origin,
        "center_to_rear_axle": c2r,
        "start_rear": start,
        "goal_rear": goal,
        "goal_body_center": goal_body_center,
        "left_body_center": left_body_center,
        "right_body_center": right_body_center,
        "row_yaw": row_yaw,
        "outer_world": outer_world,
        "start_local": (start_local_r, start_local_s),
        "goal_local": world_to_local(goal[0], goal[1], ox, oy, row_yaw),
    }
    return obstacles, drivable_area, start, goal, debug


def make_morai_fixed_seed_path(start: Tuple[float, float, float],
                               goal: Tuple[float, float, float],
                               goal_body_center: Tuple[float, float],
                               cfg: PlannerConfig) -> List[DensePathPoint]:
    """Generic two-stage seed path for the measured MORAI pose.

    1) Move forward along the aisle/row direction past the target.
    2) Reverse with a cubic-Hermite curve into the target slot.

    This keeps the same raw path interface as Hybrid A* and is used if the strict
    Hybrid A* search fails in the very narrow hand-made cone scenario.
    """
    row_yaw = normalize_angle(goal[2] - math.pi * 0.5)
    ox, oy = goal_body_center

    sr, ss = world_to_local(start[0], start[1], ox, oy, row_yaw)
    gr, gs = world_to_local(goal[0], goal[1], ox, oy, row_yaw)

    pts: List[DensePathPoint] = []

    def append_local(r, s, yaw_local, direction, steer=0.0):
        x, y = local_to_world(r, s, ox, oy, row_yaw)
        yaw = local_yaw_to_world(yaw_local, row_yaw)
        pts.append(DensePathPoint(x, y, yaw, int(direction), float(steer)))

    # Stage 1: forward pull-up in the aisle.
    pull_r = max(gr + 3.4, min(sr + 6.8, 4.4))
    pull_s = ss
    start_yaw_local = normalize_angle(start[2] - row_yaw)
    n = max(4, int(abs(pull_r - sr) / 0.12))
    for i in range(n + 1):
        t = float(i) / float(n)
        r = sr + t * (pull_r - sr)
        s = ss + t * (pull_s - ss)
        yaw_l = start_yaw_local + t * normalize_angle(0.0 - start_yaw_local)
        append_local(r, s, yaw_l, +1, 0.0)

    # Stage 2: reverse Hermite curve into goal.
    p0 = (pull_r, pull_s)
    p1 = (gr, gs)
    # Reverse starts by moving backward along -row, and finishes moving backward along -slot.
    dist = math.hypot(p1[0] - p0[0], p1[1] - p0[1])
    m0 = (-0.70 * dist, 0.0)
    m1 = (0.0, -0.70 * dist)

    n = max(20, int(dist / 0.08))
    for i in range(1, n + 1):
        t = float(i) / float(n)
        h00 = 2*t*t*t - 3*t*t + 1
        h10 = t*t*t - 2*t*t + t
        h01 = -2*t*t*t + 3*t*t
        h11 = t*t*t - t*t
        r = h00*p0[0] + h10*m0[0] + h01*p1[0] + h11*m1[0]
        s = h00*p0[1] + h10*m0[1] + h01*p1[1] + h11*m1[1]
        # derivative for path heading
        dh00 = 6*t*t - 6*t
        dh10 = 3*t*t - 4*t + 1
        dh01 = -6*t*t + 6*t
        dh11 = 3*t*t - 2*t
        dr = dh00*p0[0] + dh10*m0[0] + dh01*p1[0] + dh11*m1[0]
        ds = dh00*p0[1] + dh10*m0[1] + dh01*p1[1] + dh11*m1[1]
        path_heading_l = math.atan2(ds, dr)
        yaw_l = normalize_angle(path_heading_l + math.pi)  # reverse gear vehicle heading
        if i == n:
            yaw_l = normalize_angle(goal[2] - row_yaw)
        append_local(r, s, yaw_l, -1, 0.0)

    # Final stop samples.
    goal_yaw_local = normalize_angle(goal[2] - row_yaw)
    for _ in range(6):
        append_local(gr, gs, goal_yaw_local, -1, 0.0)
    return pts
