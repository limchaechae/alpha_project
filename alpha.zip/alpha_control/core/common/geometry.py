# -*- coding: utf-8 -*-
"""Geometry utilities used by planning, constraints, and visualization.
This module is ROS-independent so it can be unit-tested without roscore.
"""

import math
from typing import List, Tuple


def normalize_angle(angle: float) -> float:
    while angle >= math.pi:
        angle -= 2.0 * math.pi
    while angle < -math.pi:
        angle += 2.0 * math.pi
    return angle


def angle_diff(a: float, b: float) -> float:
    return normalize_angle(a - b)


def rotate_point(px: float, py: float, yaw: float) -> Tuple[float, float]:
    c = math.cos(yaw)
    s = math.sin(yaw)
    return c * px - s * py, s * px + c * py


def clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def polygon_axes(poly: List[Tuple[float, float]]) -> List[Tuple[float, float]]:
    axes = []
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % n]
        ex = x2 - x1
        ey = y2 - y1
        ax = -ey
        ay = ex
        norm = math.hypot(ax, ay)
        if norm > 1e-9:
            axes.append((ax / norm, ay / norm))
    return axes


def project_polygon(poly: List[Tuple[float, float]], axis: Tuple[float, float]) -> Tuple[float, float]:
    ax, ay = axis
    vals = [x * ax + y * ay for x, y in poly]
    return min(vals), max(vals)


def convex_polygons_intersect(poly_a: List[Tuple[float, float]], poly_b: List[Tuple[float, float]]) -> bool:
    """Separating Axis Theorem intersection test for convex polygons."""
    if len(poly_a) < 3 or len(poly_b) < 3:
        return False
    for axis in polygon_axes(poly_a) + polygon_axes(poly_b):
        a_min, a_max = project_polygon(poly_a, axis)
        b_min, b_max = project_polygon(poly_b, axis)
        if a_max < b_min or b_max < a_min:
            return False
    return True


def point_in_polygon(x: float, y: float, polygon: List[Tuple[float, float]]) -> bool:
    """Ray-casting point-in-polygon test. Works for simple concave polygons."""
    inside = False
    n = len(polygon)
    if n < 3:
        return False
    j = n - 1
    for i in range(n):
        xi, yi = polygon[i]
        xj, yj = polygon[j]
        if (yi > y) != (yj > y):
            x_cross = (xj - xi) * (y - yi) / ((yj - yi) + 1e-12) + xi
            if x < x_cross:
                inside = not inside
        j = i
    return inside


def sample_polygon_boundary(poly: List[Tuple[float, float]], samples_per_edge: int = 4) -> List[Tuple[float, float]]:
    """Return corners plus edge samples. Useful for concave drivable-area checks."""
    out = []
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % n]
        for k in range(samples_per_edge + 1):
            t = float(k) / float(samples_per_edge + 1)
            out.append((x1 + (x2 - x1) * t, y1 + (y2 - y1) * t))
    return out


def cumulative_distance_xy(points: List[Tuple[float, float]]) -> List[float]:
    s = [0.0]
    for a, b in zip(points[:-1], points[1:]):
        s.append(s[-1] + math.hypot(b[0] - a[0], b[1] - a[1]))
    return s


def rear_axle_vehicle_polygon(x: float, y: float, yaw: float,
                              wheel_base: float, front_overhang: float, rear_overhang: float,
                              vehicle_width: float, padding: float = 0.0) -> List[Tuple[float, float]]:
    """Vehicle body polygon when pose origin is rear axle center.

    Local vehicle frame:
      x=0       : rear axle center / base_link
      +x        : vehicle front direction
      front end : wheel_base + front_overhang
      rear end  : -rear_overhang
    """
    front_x = wheel_base + front_overhang + padding
    rear_x = -rear_overhang - padding
    half_w = 0.5 * vehicle_width + padding
    local = [(front_x, half_w), (front_x, -half_w), (rear_x, -half_w), (rear_x, half_w)]
    out = []
    for lx, ly in local:
        rx, ry = rotate_point(lx, ly, yaw)
        out.append((x + rx, y + ry))
    return out


def rear_axle_to_body_center(x: float, y: float, yaw: float,
                             wheel_base: float, front_overhang: float, rear_overhang: float) -> Tuple[float, float]:
    """Return body rectangle center for RViz CUBE marker from rear axle pose."""
    front_x = wheel_base + front_overhang
    rear_x = -rear_overhang
    center_local_x = 0.5 * (front_x + rear_x)
    dx, dy = rotate_point(center_local_x, 0.0, yaw)
    return x + dx, y + dy
