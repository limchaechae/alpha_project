# -*- coding: utf-8 -*-
"""ROS-independent data types for alpha_control."""

import math
from dataclasses import dataclass
from typing import List, Optional, Tuple

from .geometry import rotate_point


@dataclass(frozen=True)
class RectObstacle:
    x: float
    y: float
    yaw: float
    length: float
    width: float
    name: str = "obstacle"

    def polygon(self, padding: float = 0.0) -> List[Tuple[float, float]]:
        hl = 0.5 * self.length + padding
        hw = 0.5 * self.width + padding
        local = [(hl, hw), (hl, -hw), (-hl, -hw), (-hl, hw)]
        pts = []
        for lx, ly in local:
            rx, ry = rotate_point(lx, ly, self.yaw)
            pts.append((self.x + rx, self.y + ry))
        return pts


@dataclass
class SearchNode:
    x: float
    y: float
    yaw: float
    g: float = 0.0
    h: float = 0.0
    parent: Optional[int] = None
    direction: int = 1       # +1 forward, -1 reverse
    steer: float = 0.0
    index: Optional[Tuple[int, int, int]] = None
    traj: Optional[List[Tuple[float, float, float]]] = None

    @property
    def f(self) -> float:
        return self.g + self.h


@dataclass
class DensePathPoint:
    x: float
    y: float
    yaw: float
    direction: int
    steer: float


@dataclass
class RefTrajectoryPoint:
    t: float
    x: float
    y: float
    yaw: float
    s: float
    v: float
    a: float
    curvature: float
    steer: float
    gear: int               # +1 D, -1 R


@dataclass
class PlannerConfig:
    # Map boundary used for RViz display and sanity checks.
    min_x: float = -2.8
    max_x: float = 12.8
    min_y: float = -5.5
    max_y: float = 5.8

    # Vehicle. Pose origin is the rear axle center, not the body center.
    wheel_base: float = 2.70
    front_overhang: float = 0.75
    rear_overhang: float = 0.75
    vehicle_width: float = 1.85
    max_steer_deg: float = 35.0
    collision_padding: float = 0.035
    drivable_padding: float = 0.025

    # Parking slot dimensions used by the manual scenario.
    slot_width: float = 2.20
    slot_length: float = 4.40

    # Hybrid A*.
    xy_resolution: float = 0.35
    yaw_resolution_deg: float = 10.0
    primitive_length: float = 0.70
    integration_step: float = 0.10
    steer_sample_count: int = 7
    max_iterations: int = 90000
    goal_xy_tolerance: float = 0.55
    goal_yaw_tolerance_deg: float = 16.0

    # Costs.
    reverse_penalty: float = 1.02
    gear_switch_penalty: float = 1.70
    steer_penalty: float = 0.18
    steer_change_penalty: float = 0.32
    distance_heuristic_weight: float = 1.10
    yaw_heuristic_weight: float = 0.60

    # Reference trajectory.
    ref_ds: float = 0.15
    max_ref_speed: float = 0.90
    min_segment_time: float = 2.0

    @property
    def vehicle_length(self) -> float:
        return self.rear_overhang + self.wheel_base + self.front_overhang

    @property
    def max_steer(self) -> float:
        return math.radians(self.max_steer_deg)

    @property
    def yaw_resolution(self) -> float:
        return math.radians(self.yaw_resolution_deg)

    @property
    def goal_yaw_tolerance(self) -> float:
        return math.radians(self.goal_yaw_tolerance_deg)
