# MORAI CtrlCmd topic fix

The MORAI simulator subscribes to `/ctrl_cmd` in the current setup. `/ctrl_cmd_0` is not used by default in this package.

Expected checks:

```bash
rostopic info /ctrl_cmd
# Subscribers should include /rosbridge_websocket

rostopic info /ctrl_cmd_0
# It can be unknown; this package no longer uses it by default.
```

Run:

```bash
roslaunch alpha_control parking_morai_fixed.launch
```

If MORAI command still does not apply, run:

```bash
roslaunch alpha_control morai_command_probe.launch
rostopic echo -n 1 /alpha_control/morai_command_probe_report
```
