#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ROS wrapper for Pure Pursuit + PID reference trajectory tracking.

Inputs:
  /alpha_control/ref_trajectory    alpha_control/RefTrajectory
  /alpha_control/current_pose      geometry_msgs/PoseStamped
  /alpha_control/current_speed     std_msgs/Float64  optional, m/s signed

Outputs:
  /alpha_control/tracking_cmd          alpha_control/TrackingCommand
  /alpha_control/tracking_target_pose  geometry_msgs/PoseStamped
  /alpha_control/tracking_markers      visualization_msgs/MarkerArray

This node is intentionally simulator-agnostic. It does not publish MORAI CtrlCmd.
Later, a small adapter can convert TrackingCommand to /ctrl_cmd.
"""

import math
import os
import sys

PKG_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PKG_ROOT not in sys.path:
    sys.path.insert(0, PKG_ROOT)

import rospy
import tf.transformations
from geometry_msgs.msg import Point, PoseStamped
from std_msgs.msg import Float64
from visualization_msgs.msg import Marker, MarkerArray

from alpha_control.msg import RefTrajectory, TrackingCommand
from core.common.geometry import normalize_angle
from core.common.types import RefTrajectoryPoint
from core.control.pid_speed import PIDSpeedController
from core.control.pure_pursuit import PurePursuitController
from core.control.reference_tracker import ReferenceTracker


def yaw_from_pose(pose_msg):
    q = pose_msg.pose.orientation
    _, _, yaw = tf.transformations.euler_from_quaternion([q.x, q.y, q.z, q.w])
    return normalize_angle(yaw)


def q_from_yaw(yaw):
    return tf.transformations.quaternion_from_euler(0.0, 0.0, yaw)


class PathTrackerNode(object):
    def __init__(self):
        rospy.init_node("alpha_control_path_tracker", anonymous=False)

        wheel_base = rospy.get_param("~wheel_base", 2.70)
        max_steer_deg = rospy.get_param("~max_steer_deg", 35.0)
        min_lookahead = rospy.get_param("~min_lookahead", 0.80)
        max_lookahead = rospy.get_param("~max_lookahead", 2.50)
        lookahead_gain = rospy.get_param("~lookahead_gain", 0.85)

        kp = rospy.get_param("~speed_kp", 0.90)
        ki = rospy.get_param("~speed_ki", 0.04)
        kd = rospy.get_param("~speed_kd", 0.02)

        self.control_rate = rospy.get_param("~control_rate", 20.0)
        self.pose_timeout = rospy.get_param("~pose_timeout", 1.0)
        self.stop_on_goal = rospy.get_param("~stop_on_goal", True)

        self.ref = []
        self.current_pose = None
        self.current_yaw = 0.0
        self.current_speed = 0.0
        self.last_pose_time = None
        self.last_speed_time = None
        self.last_update_time = None

        pp = PurePursuitController(
            wheel_base=wheel_base,
            max_steer_deg=max_steer_deg,
            min_lookahead=min_lookahead,
            max_lookahead=max_lookahead,
            lookahead_gain=lookahead_gain,
        )
        pid = PIDSpeedController(kp=kp, ki=ki, kd=kd)
        self.tracker = ReferenceTracker(
            pp,
            pid,
            goal_dist_tolerance=rospy.get_param("~goal_dist_tolerance", 0.35),
            goal_speed_tolerance=rospy.get_param("~goal_speed_tolerance", 0.08),
            gear_switch_speed_tolerance=rospy.get_param("~gear_switch_speed_tolerance", 0.12),
            gear_switch_scan_points=rospy.get_param("~gear_switch_scan_points", 20),
        )

        self.ref_sub = rospy.Subscriber("/alpha_control/ref_trajectory", RefTrajectory, self.ref_callback, queue_size=1)
        self.pose_sub = rospy.Subscriber("/alpha_control/current_pose", PoseStamped, self.pose_callback, queue_size=1)
        self.speed_sub = rospy.Subscriber("/alpha_control/current_speed", Float64, self.speed_callback, queue_size=1)

        self.cmd_pub = rospy.Publisher("/alpha_control/tracking_cmd", TrackingCommand, queue_size=1)
        self.target_pub = rospy.Publisher("/alpha_control/tracking_target_pose", PoseStamped, queue_size=1)
        self.marker_pub = rospy.Publisher("/alpha_control/tracking_markers", MarkerArray, queue_size=1)

        rospy.loginfo("Path tracker initialized: Pure Pursuit + PID")

    def ref_callback(self, msg):
        self.ref = [
            RefTrajectoryPoint(
                t=p.t, x=p.x, y=p.y, yaw=p.yaw, s=p.s, v=p.v, a=p.a,
                curvature=p.curvature, steer=p.steer, gear=p.gear
            ) for p in msg.points
        ]
        self.tracker.reset()
        rospy.loginfo("Reference trajectory received: %d points", len(self.ref))

    def pose_callback(self, msg):
        now = msg.header.stamp if msg.header.stamp != rospy.Time(0) else rospy.Time.now()
        yaw = yaw_from_pose(msg)

        # If no explicit speed topic is available, estimate signed speed from pose difference.
        if self.current_pose is not None and (self.last_speed_time is None or (rospy.Time.now() - self.last_speed_time).to_sec() > 0.5):
            dt = (now - self.last_pose_time).to_sec() if self.last_pose_time is not None else 0.0
            if dt > 1e-3:
                dx = msg.pose.position.x - self.current_pose.pose.position.x
                dy = msg.pose.position.y - self.current_pose.pose.position.y
                speed_mag = math.hypot(dx, dy) / dt
                # Project displacement onto vehicle heading to estimate sign.
                signed = dx * math.cos(yaw) + dy * math.sin(yaw)
                self.current_speed = speed_mag if signed >= 0.0 else -speed_mag

        self.current_pose = msg
        self.current_yaw = yaw
        self.last_pose_time = now

    def speed_callback(self, msg):
        self.current_speed = msg.data
        self.last_speed_time = rospy.Time.now()

    def make_cmd_msg(self, result):
        msg = TrackingCommand()
        msg.header.stamp = rospy.Time.now()
        msg.header.frame_id = "map"
        msg.target_speed = result.target_speed
        msg.current_speed = result.current_speed
        msg.accel_cmd = result.accel_cmd
        msg.brake_cmd = result.brake_cmd
        msg.steering_rad = result.steering_rad
        msg.gear = result.gear
        msg.nearest_index = result.nearest_index
        msg.target_index = result.target_index
        msg.lookahead_distance = result.lookahead_distance
        msg.lateral_error = result.lateral_error
        msg.heading_error = result.heading_error
        msg.goal_reached = result.goal_reached
        return msg

    def publish_target_pose(self, result):
        ps = PoseStamped()
        ps.header.stamp = rospy.Time.now()
        ps.header.frame_id = "map"
        ps.pose.position.x = result.target_x
        ps.pose.position.y = result.target_y
        ps.pose.position.z = 0.0
        q = q_from_yaw(result.target_yaw)
        ps.pose.orientation.x, ps.pose.orientation.y, ps.pose.orientation.z, ps.pose.orientation.w = q
        self.target_pub.publish(ps)

    def publish_markers(self, result):
        ma = MarkerArray()
        delete = Marker()
        delete.action = Marker.DELETEALL
        ma.markers.append(delete)

        # Lookahead target sphere
        m = Marker()
        m.header.stamp = rospy.Time.now()
        m.header.frame_id = "map"
        m.ns = "tracking_target"
        m.id = 1
        m.type = Marker.SPHERE
        m.action = Marker.ADD
        m.pose.position.x = result.target_x
        m.pose.position.y = result.target_y
        m.pose.position.z = 0.25
        m.pose.orientation.w = 1.0
        m.scale.x = 0.28
        m.scale.y = 0.28
        m.scale.z = 0.28
        m.color.r = 1.0
        m.color.g = 1.0
        m.color.b = 0.0
        m.color.a = 1.0
        ma.markers.append(m)

        # Line from current pose to target
        if self.current_pose is not None:
            line = Marker()
            line.header.stamp = rospy.Time.now()
            line.header.frame_id = "map"
            line.ns = "tracking_lookahead_line"
            line.id = 2
            line.type = Marker.LINE_STRIP
            line.action = Marker.ADD
            line.pose.orientation.w = 1.0
            line.scale.x = 0.05
            line.color.r = 1.0
            line.color.g = 1.0
            line.color.b = 0.0
            line.color.a = 0.9
            p0 = Point()
            p0.x = self.current_pose.pose.position.x
            p0.y = self.current_pose.pose.position.y
            p0.z = 0.20
            p1 = Point()
            p1.x = result.target_x
            p1.y = result.target_y
            p1.z = 0.20
            line.points = [p0, p1]
            ma.markers.append(line)

        text = Marker()
        text.header.stamp = rospy.Time.now()
        text.header.frame_id = "map"
        text.ns = "tracking_status"
        text.id = 3
        text.type = Marker.TEXT_VIEW_FACING
        text.action = Marker.ADD
        text.pose.position.x = result.target_x
        text.pose.position.y = result.target_y
        text.pose.position.z = 0.85
        text.pose.orientation.w = 1.0
        text.scale.z = 0.25
        text.color.r = 1.0
        text.color.g = 1.0
        text.color.b = 1.0
        text.color.a = 1.0
        text.text = "target idx: %d\ngear: %s\nsteer: %.2f deg\nv: %.2f -> %.2f" % (
            result.target_index,
            "D" if result.gear >= 0 else "R",
            math.degrees(result.steering_rad),
            result.current_speed,
            result.target_speed,
        )
        ma.markers.append(text)
        self.marker_pub.publish(ma)

    def spin(self):
        rate = rospy.Rate(self.control_rate)
        self.last_update_time = rospy.Time.now()
        while not rospy.is_shutdown():
            now = rospy.Time.now()
            dt = (now - self.last_update_time).to_sec()
            self.last_update_time = now

            if not self.ref:
                rate.sleep()
                continue
            if self.current_pose is None:
                rate.sleep()
                continue
            if self.last_pose_time is not None and (now - self.last_pose_time).to_sec() > self.pose_timeout:
                rospy.logwarn_throttle(1.0, "No recent /alpha_control/current_pose")
                rate.sleep()
                continue

            x = self.current_pose.pose.position.x
            y = self.current_pose.pose.position.y
            result = self.tracker.update(self.ref, x, y, self.current_yaw, self.current_speed, dt)
            if result is None:
                rate.sleep()
                continue

            self.cmd_pub.publish(self.make_cmd_msg(result))
            self.publish_target_pose(result)
            self.publish_markers(result)

            if result.goal_reached and self.stop_on_goal:
                rospy.loginfo_throttle(1.0, "Goal reached. Tracker is commanding stop.")

            rate.sleep()


if __name__ == "__main__":
    try:
        PathTrackerNode().spin()
    except rospy.ROSInterruptException:
        pass
