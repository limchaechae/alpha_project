#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Virtual rear-axle vehicle simulator for RViz tracking demo.

Subscriptions:
  /alpha_control/ref_trajectory   alpha_control/RefTrajectory
  /alpha_control/tracking_cmd     alpha_control/TrackingCommand

Publications:
  /alpha_control/current_pose     geometry_msgs/PoseStamped
  /alpha_control/current_speed    std_msgs/Float64, signed m/s
  /alpha_control/actual_path      nav_msgs/Path
  /alpha_control/vehicle_markers  visualization_msgs/MarkerArray
  TF map -> base_link

This node closes the loop for RViz-only testing:
  planner -> ref_trajectory -> tracker -> tracking_cmd -> virtual_vehicle -> current_pose -> tracker
"""

import math
import os
import sys

PKG_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PKG_ROOT not in sys.path:
    sys.path.insert(0, PKG_ROOT)

import rospy
import tf
from geometry_msgs.msg import Point, PoseStamped
from nav_msgs.msg import Path
from std_msgs.msg import Float64
from visualization_msgs.msg import Marker, MarkerArray

from alpha_control.msg import RefTrajectory, TrackingCommand
from core.common.geometry import rear_axle_to_body_center, rear_axle_vehicle_polygon
from core.simulation.kinematic_bicycle import RearAxleBicycleSimulator


def q_from_yaw(yaw):
    return tf.transformations.quaternion_from_euler(0.0, 0.0, yaw)


class VirtualVehicleNode(object):
    def __init__(self):
        rospy.init_node("alpha_control_virtual_vehicle", anonymous=False)

        self.wheel_base = rospy.get_param("~wheel_base", 2.70)
        self.front_overhang = rospy.get_param("~front_overhang", 0.75)
        self.rear_overhang = rospy.get_param("~rear_overhang", 0.75)
        self.vehicle_width = rospy.get_param("~vehicle_width", 1.85)
        self.vehicle_length = self.rear_overhang + self.wheel_base + self.front_overhang
        self.sim_rate = rospy.get_param("~sim_rate", 30.0)
        self.accel_limit = rospy.get_param("~accel_limit", 0.80)
        self.start_from_ref = rospy.get_param("~virtual_vehicle_start_from_ref", True)

        self.sim = RearAxleBicycleSimulator(self.wheel_base, self.accel_limit)
        self.has_ref = False
        self.has_cmd = False
        self.cmd = None
        self.actual = []
        self.last_time = None

        self.ref_sub = rospy.Subscriber("/alpha_control/ref_trajectory", RefTrajectory, self.ref_callback, queue_size=1)
        self.cmd_sub = rospy.Subscriber("/alpha_control/tracking_cmd", TrackingCommand, self.cmd_callback, queue_size=1)

        self.pose_pub = rospy.Publisher("/alpha_control/current_pose", PoseStamped, queue_size=1)
        self.speed_pub = rospy.Publisher("/alpha_control/current_speed", Float64, queue_size=1)
        self.path_pub = rospy.Publisher("/alpha_control/actual_path", Path, queue_size=1)
        self.marker_pub = rospy.Publisher("/alpha_control/vehicle_markers", MarkerArray, queue_size=1)
        self.br = tf.TransformBroadcaster()

        rospy.loginfo("Virtual rear-axle vehicle initialized: body %.2f x %.2f, L=%.2f", self.vehicle_length, self.vehicle_width, self.wheel_base)

    def ref_callback(self, msg):
        if not msg.points:
            return
        if self.has_ref and not self.start_from_ref:
            return
        first = msg.points[0]
        self.sim.reset(first.x, first.y, first.yaw, 0.0)
        self.actual = [(first.x, first.y, first.yaw)]
        self.has_ref = True
        rospy.loginfo("Virtual vehicle reset from first reference point: rear axle x=%.2f y=%.2f yaw=%.1f deg", first.x, first.y, math.degrees(first.yaw))
        self.publish_all()

    def cmd_callback(self, msg):
        self.cmd = msg
        self.has_cmd = True

    def pose_msg(self):
        st = self.sim.state
        ps = PoseStamped()
        ps.header.stamp = rospy.Time.now()
        ps.header.frame_id = "map"
        ps.pose.position.x = st.x
        ps.pose.position.y = st.y
        ps.pose.position.z = 0.0
        q = q_from_yaw(st.yaw)
        ps.pose.orientation.x, ps.pose.orientation.y, ps.pose.orientation.z, ps.pose.orientation.w = q
        return ps

    def path_msg(self):
        msg = Path()
        msg.header.stamp = rospy.Time.now()
        msg.header.frame_id = "map"
        for x, y, yaw in self.actual[-3000:]:
            ps = PoseStamped()
            ps.header = msg.header
            ps.pose.position.x = x
            ps.pose.position.y = y
            ps.pose.position.z = 0.0
            q = q_from_yaw(yaw)
            ps.pose.orientation.x, ps.pose.orientation.y, ps.pose.orientation.z, ps.pose.orientation.w = q
            msg.poses.append(ps)
        return msg

    def make_markers(self):
        st = self.sim.state
        ma = MarkerArray()
        delete = Marker()
        delete.action = Marker.DELETEALL
        ma.markers.append(delete)

        # Body cube, shifted because pose origin is rear axle center.
        cx, cy = rear_axle_to_body_center(st.x, st.y, st.yaw, self.wheel_base, self.front_overhang, self.rear_overhang)
        body = Marker()
        body.header.stamp = rospy.Time.now()
        body.header.frame_id = "map"
        body.ns = "virtual_vehicle_body"
        body.id = 1
        body.type = Marker.CUBE
        body.action = Marker.ADD
        body.pose.position.x = cx
        body.pose.position.y = cy
        body.pose.position.z = 0.12
        q = q_from_yaw(st.yaw)
        body.pose.orientation.x, body.pose.orientation.y, body.pose.orientation.z, body.pose.orientation.w = q
        body.scale.x = self.vehicle_length
        body.scale.y = self.vehicle_width
        body.scale.z = 0.24
        body.color.r = 0.1
        body.color.g = 0.9
        body.color.b = 1.0
        body.color.a = 0.55
        ma.markers.append(body)

        # Body outline using exact rear-axle polygon.
        poly = rear_axle_vehicle_polygon(st.x, st.y, st.yaw, self.wheel_base, self.front_overhang, self.rear_overhang, self.vehicle_width, 0.0)
        outline = Marker()
        outline.header.stamp = rospy.Time.now()
        outline.header.frame_id = "map"
        outline.ns = "virtual_vehicle_outline"
        outline.id = 2
        outline.type = Marker.LINE_STRIP
        outline.action = Marker.ADD
        outline.pose.orientation.w = 1.0
        outline.scale.x = 0.055
        outline.color.r = 0.0
        outline.color.g = 1.0
        outline.color.b = 1.0
        outline.color.a = 1.0
        for x, y in poly + [poly[0]]:
            p = Point(); p.x = x; p.y = y; p.z = 0.26
            outline.points.append(p)
        ma.markers.append(outline)

        # Rear axle point.
        rear = Marker()
        rear.header.stamp = rospy.Time.now()
        rear.header.frame_id = "map"
        rear.ns = "rear_axle_center"
        rear.id = 3
        rear.type = Marker.SPHERE
        rear.action = Marker.ADD
        rear.pose.position.x = st.x
        rear.pose.position.y = st.y
        rear.pose.position.z = 0.32
        rear.pose.orientation.w = 1.0
        rear.scale.x = rear.scale.y = rear.scale.z = 0.22
        rear.color.r = 0.0
        rear.color.g = 1.0
        rear.color.b = 1.0
        rear.color.a = 1.0
        ma.markers.append(rear)

        # Front axle point.
        fx = st.x + self.wheel_base * math.cos(st.yaw)
        fy = st.y + self.wheel_base * math.sin(st.yaw)
        front = Marker()
        front.header.stamp = rospy.Time.now()
        front.header.frame_id = "map"
        front.ns = "front_axle_center"
        front.id = 4
        front.type = Marker.SPHERE
        front.action = Marker.ADD
        front.pose.position.x = fx
        front.pose.position.y = fy
        front.pose.position.z = 0.32
        front.pose.orientation.w = 1.0
        front.scale.x = front.scale.y = front.scale.z = 0.18
        front.color.r = 1.0
        front.color.g = 0.55
        front.color.b = 0.0
        front.color.a = 1.0
        ma.markers.append(front)

        return ma

    def publish_all(self):
        st = self.sim.state
        now = rospy.Time.now()
        pose = self.pose_msg()
        self.pose_pub.publish(pose)
        self.speed_pub.publish(Float64(st.v))
        self.path_pub.publish(self.path_msg())
        self.marker_pub.publish(self.make_markers())
        q = q_from_yaw(st.yaw)
        self.br.sendTransform((st.x, st.y, 0.0), q, now, "base_link", "map")

    def spin(self):
        rate = rospy.Rate(self.sim_rate)
        self.last_time = rospy.Time.now()
        while not rospy.is_shutdown():
            now = rospy.Time.now()
            dt = (now - self.last_time).to_sec()
            self.last_time = now

            if self.has_ref and self.has_cmd and self.cmd is not None:
                if not self.cmd.goal_reached:
                    st = self.sim.step(
                        steering_rad=self.cmd.steering_rad,
                        gear=self.cmd.gear,
                        accel_cmd=self.cmd.accel_cmd,
                        brake_cmd=self.cmd.brake_cmd,
                        dt=dt,
                    )
                    self.actual.append((st.x, st.y, st.yaw))
                    if len(self.actual) > 3000:
                        self.actual = self.actual[-3000:]
                else:
                    self.sim.state.v = 0.0

            if self.has_ref:
                self.publish_all()

            rate.sleep()


if __name__ == "__main__":
    try:
        VirtualVehicleNode().spin()
    except rospy.ROSInterruptException:
        pass
